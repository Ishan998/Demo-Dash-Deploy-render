import React, { useState, useMemo, useEffect } from 'react';
import type { Product, WishlistItem, CartItem, MegaMenuLink } from '../types';
import { fetchProducts, fetchCategories, fetchSubcategories, fetchOccasions } from '../services/apiService';
import ProductCard from '../components/ProductCard';
import { SearchIcon, CloseIcon, FilterIcon } from '../components/Icon';
import ProductCardSkeleton from '../components/ProductCardSkeleton';

type Filter = MegaMenuLink['filter'];

interface AllProductsPageProps {
  wishlistItems: WishlistItem[];
  cartItems: CartItem[];
  onToggleWishlist: (id: number) => void;
  onToggleCart: (id: number) => void;
  onSelectProduct: (product: Product) => void;
  onBuyNow: (id: number) => void;
  initialFilters: Filter[] | null;
  onClearInitialFilters: () => void;
  initialSearchQuery: string | null;
  onClearInitialSearchQuery: () => void;
}

interface FilterCheckboxProps {
  id: string;
  label: string;
  value: string;
  isChecked: boolean;
  onChange: (value: string) => void;
}

const FilterCheckbox: React.FC<FilterCheckboxProps> = ({ id, label, value, isChecked, onChange }) => (
      <div className="flex items-center">
        <input 
          id={id} 
          type="checkbox" 
          checked={isChecked}
          onChange={() => onChange(value)}
          className="h-4 w-4 rounded border-gray-300 text-[#D4AF37] focus:ring-[#D4AF37]"
        />
        <label htmlFor={id} className="ml-3 text-sm text-gray-600">{label}</label>
      </div>
  );

const AllProductsPage: React.FC<AllProductsPageProps> = (props) => {
  const { initialFilters, onClearInitialFilters, initialSearchQuery, onClearInitialSearchQuery } = props;
  const [isLoading, setIsLoading] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [activeMainCategory, setActiveMainCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState('all');
  const [selectedCategoryFilters, setSelectedCategoryFilters] = useState<Set<string>>(new Set());
  const [selectedMetals, setSelectedMetals] = useState<Set<string>>(new Set());
  const [selectedGemstones, setSelectedGemstones] = useState<Set<string>>(new Set());
  const [selectedOccasions, setSelectedOccasions] = useState<Set<string>>(new Set());
  const [selectedSizes, setSelectedSizes] = useState<Set<string>>(new Set());
  const [selectedColors, setSelectedColors] = useState<Set<string>>(new Set());
  const [selectedDiscountTier, setSelectedDiscountTier] = useState<number>(0);
  const [showInStockOnly, setShowInStockOnly] = useState(false);
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  
  // Dynamic Category data from Admin Settings
  const [categoryNames, setCategoryNames] = useState<string[]>([]);
  const [subcategoryMap, setSubcategoryMap] = useState<Record<string, string[]>>({});
  
  const maxPrice = useMemo(() => {
    if (!products.length) return 0;
    const mx = Math.max(...products.map(p => p.originalPrice || p.price || 0));
    return Math.ceil(mx / 1000) * 1000;
  }, [products]);
  
  const [priceRange, setPriceRange] = useState({ min: 0, max: maxPrice });

  // Map API product (with variants & tags) to UI Product[] cards
  const mapBadge = (tags: any[] | undefined): Product['badge'] | undefined => {
    if (!tags || !Array.isArray(tags)) return undefined;
    if (tags.includes('Featured Products')) return 'Featured';
    if (tags.includes('New Arrival')) return 'New Arrivals';
    if (tags.includes('Best Sellers')) return 'Best Seller';
    if (tags.includes('Festive Sale')) return 'Festive Sale';
    if (tags.includes('Limited Offer') || tags.includes('Limited Deal')) return 'Limited';
    if (tags.includes('Sale')) return 'Sale';
    return undefined;
  };

  const mapApiToUi = (p: any): Product => {
    const imageUrl = p.images?.[0] || '';
    const price = Number(p.selling_price || p.mrp || 0);
    const originalPrice = p.mrp ? Number(p.mrp) : undefined;
    return {
      id: p.id,
      name: p.name,
      category: p.main_category || '',
      subcategory: p.sub_category || undefined,
      price,
      originalPrice,
      imageUrl,
      inStock: p.status !== 'out_of_stock',
      badge: mapBadge(p.tags),
      stock: p.stock,
      metal: p.materials?.[0],
      gemstone: p.crystal_name,
      color: p.colors?.[0],
      occasion: p.occasions?.[0],
      images: p.images,
    } as Product;
  };

  const expandWithVariants = (p: any): Product[] => {
    const base = mapApiToUi(p);
    const out: Product[] = [base];
    if (Array.isArray(p.variants) && p.variants.length) {
      p.variants.forEach((v: any) => {
        const vPrice = Number(v.selling_price || v.mrp || base.price || 0);
        const vOriginal = v.mrp ? Number(v.mrp) : base.originalPrice;
        const vImage = v.images?.[0] || base.imageUrl;
        out.push({
          ...base,
          // keep parent product id so actions (wishlist/cart) stay consistent
          name: v.name ? `${base.name} - ${v.name}` : base.name,
          price: vPrice,
          originalPrice: vOriginal,
          imageUrl: vImage,
          inStock: (v.stock || 0) > 0 || base.inStock,
        });
      });
    }
    return out;
  };

  useEffect(() => {
    // When products load, initialize price range's max so filtering doesn't hide items
    if (maxPrice && (priceRange.max === 0 || priceRange.max < maxPrice)) {
      setPriceRange(r => ({ ...r, min: 0, max: maxPrice }));
    }
  }, [maxPrice]);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetchProducts();
        const list = Array.isArray(res) ? res : [];
        const flattened: Product[] = list.flatMap((p: any) => expandWithVariants(p));
        setProducts(flattened);
      } catch (e) {
        console.error('Failed to load products', e);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, []);

  // Load categories and subcategories from storefront
  useEffect(() => {
    const loadCats = async () => {
      try {
        const [cats, subs] = await Promise.all([fetchCategories(), fetchSubcategories()]);
        const names = (cats || []).map((c: any) => (c?.name || '').toString()).filter(Boolean);
        setCategoryNames(names);
        const map: Record<string, string[]> = {};
        (subs || []).forEach((s: any) => {
          const main = (s?.main_category_name || '').toString();
          const sub = (s?.name || '').toString();
          if (!main || !sub) return;
          if (!map[main]) map[main] = [];
          if (!map[main].includes(sub)) map[main].push(sub);
        });
        Object.keys(map).forEach((k) => map[k].sort());
        setSubcategoryMap(map);
      } catch (e) {
        console.error('Failed to load categories/subcategories', e);
      }
    };
    loadCats();
  }, []);

  // Load occasions from storefront settings (Admin)
  useEffect(() => {
    const loadOcc = async () => {
      try {
        const occs = await fetchOccasions();
        const names = (occs || []).map((o: any) => (o?.name || '').toString()).filter(Boolean);
        setOccasionNames(Array.from(new Set(names)).sort());
      } catch (e) {
        console.error('Failed to load occasions', e);
      }
    };
    loadOcc();
  }, []);

  const allMetals = useMemo(() => Array.from(new Set(products.flatMap(p => p.metal ? [p.metal] : []))).sort(), [products]);
  const allGemstones = useMemo(() => Array.from(new Set(products.flatMap(p => p.gemstone ? [p.gemstone] : []))).sort(), [products]);
  const [occasionNames, setOccasionNames] = useState<string[]>([]);
  const allSizes = useMemo(() => Array.from(new Set(products.flatMap(p => p.size ? [p.size] : []))).sort(), [products]);
  const allColors = useMemo(() => Array.from(new Set(products.flatMap(p => p.color ? [p.color] : []))).sort(), [products]);
  const discountTiers = [
      { label: 'Products With Discounts', value: 1 },
      { label: 'More than 50% off', value: 50 },
      { label: '30% off & more', value: 30 },
      { label: '20% off & more', value: 20 },
  ];

  const resetFilters = () => {
    setActiveMainCategory(null);
    setSearchQuery('');
    setSortOption('all');
    setSelectedCategoryFilters(new Set());
    setSelectedMetals(new Set());
    setSelectedGemstones(new Set());
    setSelectedOccasions(new Set());
    setSelectedSizes(new Set());
    setSelectedColors(new Set());
    setSelectedDiscountTier(0);
    setShowInStockOnly(false);
    setPriceRange({ min: 0, max: maxPrice });
  };
  
  const handleViewAllCategories = () => {
    setActiveMainCategory(null);
    setSelectedCategoryFilters(new Set());
  };


  const handleSetChange = (setter: React.Dispatch<React.SetStateAction<Set<string>>>, value: string) => {
    setter(prev => {
      const newSet = new Set(prev);
      if (newSet.has(value)) {
        newSet.delete(value);
      } else {
        newSet.add(value);
      }
      return newSet;
    });
  };
  
  useEffect(() => {
    if (initialSearchQuery) {
        setSearchQuery(initialSearchQuery);
        onClearInitialSearchQuery();
    }
  }, [initialSearchQuery, onClearInitialSearchQuery]);

  useEffect(() => {
    if (initialFilters && initialFilters.length > 0) {
        resetFilters(); // Start with a clean slate to avoid merging filters

        const mainCatFilter = initialFilters.find(f => f?.type === 'category');
        
        if (mainCatFilter) {
            setActiveMainCategory(mainCatFilter.value);
            const subCatFilters = initialFilters
                .filter(f => f?.type === 'subcategory')
                .map(f => f!.value);
            setSelectedCategoryFilters(new Set(subCatFilters));
        } else {
            setActiveMainCategory(null);
            const categoryBasedFilters = initialFilters
              .filter(f => f && (f.type === 'category' || f.type === 'subcategory'))
              .map(f => f!.value);
            setSelectedCategoryFilters(new Set(categoryBasedFilters));
        }
        
        const badgeFilter = initialFilters.find(f => f?.type === 'badge');
        if (badgeFilter) {
            const badgeToSortOptionMap: { [key: string]: string } = {
                'Featured': 'featured',
                'New Arrivals': 'new-arrivals',
                'Best Seller': 'best-sellers',
                'Festive Sale': 'festive-sale',
                'Sale': 'festive-sale',
                'Limited': 'limited-deals'
            };
            if (badgeToSortOptionMap[badgeFilter.value]) {
                setSortOption(badgeToSortOptionMap[badgeFilter.value]);
            }
        }

        // Preselect filters from 'material', 'color', 'gemstone', and 'occasion' initial filters
        const materialFilters = initialFilters.filter(f => f?.type === 'material');
        if (materialFilters.length) {
            setSelectedMetals(new Set(materialFilters.map(f => f.value)));
        }
        const colorFilters = initialFilters.filter(f => f?.type === 'color');
        if (colorFilters.length) {
            setSelectedColors(new Set(colorFilters.map(f => f.value)));
        }
        const gemFilters = initialFilters.filter(f => f?.type === 'gemstone');
        if (gemFilters.length) {
            setSelectedGemstones(new Set(gemFilters.map(f => f.value)));
        }
        const occFilters = initialFilters.filter(f => f?.type === 'occasion');
        if (occFilters.length) {
            setSelectedOccasions(new Set(occFilters.map(f => f.value)));
        }

        onClearInitialFilters();
    }
  }, [initialFilters, onClearInitialFilters]);


  const filteredAndSortedProducts = useMemo(() => {
    let tempProducts = [...products];

    // Handle special badge "sort" options which are actually filters
    switch (sortOption) {
        case 'featured': tempProducts = tempProducts.filter(p => p.badge === 'Featured'); break;
        case 'new-arrivals': tempProducts = tempProducts.filter(p => p.badge === 'New Arrivals'); break;
        case 'best-sellers': tempProducts = tempProducts.filter(p => p.badge === 'Best Seller'); break;
        case 'festive-sale': tempProducts = tempProducts.filter(p => p.badge === 'Festive Sale' || p.badge === 'Sale'); break;
        case 'limited-deals': tempProducts = tempProducts.filter(p => p.badge === 'Limited'); break;
    }

    // Apply category filters
    if (activeMainCategory) {
        tempProducts = tempProducts.filter(p => p.category === activeMainCategory);
        if (selectedCategoryFilters.size > 0) {
            tempProducts = tempProducts.filter(p => {
                const styleIdentifier = p.subcategory && p.style ? `${p.subcategory}-${p.style}` : null;
                return (p.subcategory && selectedCategoryFilters.has(p.subcategory)) || (styleIdentifier && selectedCategoryFilters.has(styleIdentifier));
            });
        }
    } else {
        if (selectedCategoryFilters.size > 0) {
            tempProducts = tempProducts.filter(p => {
                const styleIdentifier = p.subcategory && p.style ? `${p.subcategory}-${p.style}` : null;
                return selectedCategoryFilters.has(p.category) || (p.subcategory && selectedCategoryFilters.has(p.subcategory)) || (styleIdentifier && selectedCategoryFilters.has(styleIdentifier));
            });
        }
    }

    // Apply other filters
    tempProducts = tempProducts
      .filter(p => {
        const lowerCaseQuery = searchQuery.toLowerCase();
        if (!lowerCaseQuery) return true;
        return (
            p.name.toLowerCase().includes(lowerCaseQuery) ||
            p.category.toLowerCase().includes(lowerCaseQuery) ||
            (p.subcategory && p.subcategory.toLowerCase().includes(lowerCaseQuery)) ||
            (p.style && p.style.toLowerCase().includes(lowerCaseQuery)) ||
            (p.metal && p.metal.toLowerCase().includes(lowerCaseQuery)) ||
            (p.gemstone && p.gemstone.toLowerCase().includes(lowerCaseQuery)) ||
            (p.color && p.color.toLowerCase().includes(lowerCaseQuery)) ||
            (p.occasion && p.occasion.toLowerCase().includes(lowerCaseQuery))
        )
      })
      .filter(p => selectedMetals.size === 0 || (p.metal && selectedMetals.has(p.metal)))
      .filter(p => selectedGemstones.size === 0 || (p.gemstone && selectedGemstones.has(p.gemstone)))
      .filter(p => selectedOccasions.size === 0 || (p.occasion && selectedOccasions.has(p.occasion)))
      .filter(p => selectedSizes.size === 0 || (p.size && selectedSizes.has(p.size)))
      .filter(p => selectedColors.size === 0 || (p.color && selectedColors.has(p.color)))
      .filter(p => {
        if (selectedDiscountTier === 0) return true;
        if (!p.originalPrice || p.originalPrice <= p.price) return false;
        const discount = ((p.originalPrice - p.price) / p.originalPrice) * 100;
        return discount >= selectedDiscountTier;
      })
      .filter(p => !showInStockOnly || p.inStock)
      .filter(p => (p.originalPrice || p.price) >= priceRange.min && (p.originalPrice || p.price) <= priceRange.max);

    // Apply actual sorting for non-badge options
    switch (sortOption) {
      case 'price-asc': tempProducts.sort((a, b) => a.price - b.price); break;
      case 'price-desc': tempProducts.sort((a, b) => b.price - a.price); break;
      case 'name-asc': tempProducts.sort((a, b) => a.name.localeCompare(b.name)); break;
      case 'name-desc': tempProducts.sort((a, b) => b.name.localeCompare(a.name)); break;
      default: tempProducts.sort((a, b) => a.id - b.id); break;
    }
    return tempProducts;
  }, [products, searchQuery, sortOption, selectedCategoryFilters, showInStockOnly, priceRange, selectedMetals, selectedGemstones, selectedOccasions, selectedSizes, selectedColors, selectedDiscountTier, activeMainCategory]);
  
  useEffect(() => {
    document.body.style.overflow = isFiltersOpen ? 'hidden' : 'auto';
    return () => { document.body.style.overflow = 'auto'; };
  }, [isFiltersOpen]);
  
  const getSubCategoriesFor = (mainCat: string) => {
      const subCats = subcategoryMap[mainCat] || [];
      return subCats.map(sc => ({ name: sc, styles: [] as string[] }));
  };

  const FilterPanel = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Filters</h3>
        <button onClick={resetFilters} className="text-sm text-gray-600 hover:text-red-500 transition">Reset</button>
      </div>

       <details className="group py-2 border-b" open>
            <summary className="font-semibold cursor-pointer list-none flex justify-between items-center">
                Category
                {activeMainCategory && (
                    <button 
                        onClick={handleViewAllCategories} 
                        className="text-xs font-normal text-blue-600 hover:underline"
                    >
                        View All Categories
                    </button>
                )}
                <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span>
            </summary>
            {activeMainCategory ? (
                <div className="pl-2 mt-3">
                    <h4 className="font-bold text-gray-800 mb-2">{activeMainCategory}</h4>
                    <div className="space-y-1 max-h-60 overflow-y-auto pr-2 pl-2 border-l">
                        {getSubCategoriesFor(activeMainCategory).map(subCat => (
                            subCat.styles.length > 0 ? (
                                <details key={subCat.name} className="group/sub py-1">
                                    <summary className="cursor-pointer list-none flex items-center justify-between font-medium text-gray-800 text-sm">
                                        {subCat.name}
                                        <span className="transition-transform duration-200 group-open/sub:rotate-90">&gt;</span>
                                    </summary>
                                    <div className="space-y-2 mt-2 pl-4 border-l">
                                        {subCat.styles.map(style => (
                                            <FilterCheckbox key={`${subCat.name}-${style}`} id={`cat-${subCat.name}-${style}`} label={style} value={`${subCat.name}-${style}`} isChecked={selectedCategoryFilters.has(`${subCat.name}-${style}`)} onChange={(val) => handleSetChange(setSelectedCategoryFilters, val)} />
                                        ))}
                                    </div>
                                </details>
                            ) : (
                                <div key={subCat.name} className="py-1">
                                    <FilterCheckbox id={`cat-${subCat.name}`} label={subCat.name} value={subCat.name} isChecked={selectedCategoryFilters.has(subCat.name)} onChange={(val) => handleSetChange(setSelectedCategoryFilters, val)} />
                                </div>
                            )
                        ))}
                    </div>
                    {selectedCategoryFilters.size > 0 && (
                        <button 
                            onClick={() => setSelectedCategoryFilters(new Set())} 
                            className="text-sm w-full text-center mt-3 p-2 bg-gray-100 rounded-md hover:bg-gray-200"
                        >
                            View All in {activeMainCategory}
                        </button>
                    )}
                </div>
            ) : (
                <div className="space-y-1 mt-3 max-h-60 overflow-y-auto pr-2">
                  {categoryNames.map((mainCat) => {
                    const subs = subcategoryMap[mainCat] || [];
                    return (
                      subs.length === 0 ? (
                        <div key={mainCat} className="pl-1 py-1">
                          <FilterCheckbox id={`cat-${mainCat}`} label={mainCat} value={mainCat} isChecked={selectedCategoryFilters.has(mainCat)} onChange={(val) => handleSetChange(setSelectedCategoryFilters, val)} />
                        </div>
                      ) : (
                        <details key={mainCat} className="group/sub py-1">
                          <summary className="cursor-pointer list-none flex items-center justify-between font-medium text-gray-800 text-sm">{mainCat}<span className="transition-transform duration-200 group-open/sub:rotate-90">&gt;</span></summary>
                          <div className="space-y-2 mt-2 pl-4 border-l">
                            {subs.map((subCat) => (
                              <FilterCheckbox key={subCat} id={`cat-${subCat}`} label={subCat} value={subCat} isChecked={selectedCategoryFilters.has(subCat)} onChange={(val) => handleSetChange(setSelectedCategoryFilters, val)} />
                            ))}
                          </div>
                        </details>
                      )
                    );
                  })}
                </div>
            )}
      </details>

      <details className="group py-2 border-b" open>
        <summary className="font-semibold cursor-pointer list-none flex justify-between items-center">Price Range <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span></summary>
        <div className="flex items-center space-x-2 mt-3">
            <div className="relative w-full"><span className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 text-sm">₹</span><input type="number" placeholder="Min" value={priceRange.min} onChange={e => setPriceRange(p => ({...p, min: Number(e.target.value)}))} className="w-full p-2 pl-5 border border-gray-300 rounded-md text-sm" /></div>
            <span className="text-gray-400">-</span>
            <div className="relative w-full"><span className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 text-sm">₹</span><input type="number" placeholder="Max" value={priceRange.max} onChange={e => setPriceRange(p => ({...p, max: Number(e.target.value)}))} className="w-full p-2 pl-5 border border-gray-300 rounded-md text-sm" /></div>
        </div>
        <input type="range" min="0" max={maxPrice} value={priceRange.max} onChange={e => setPriceRange(p => ({...p, max: Number(e.target.value)}))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-3 accent-[#D4AF37]" />
      </details>
      
      <details className="group py-2 border-b">
          <summary className="font-semibold cursor-pointer list-none flex justify-between items-center">Discount <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span></summary>
          <div className="space-y-2 mt-3">
            <div className="flex items-center"><input id="discount-all" type="radio" name="discount" checked={selectedDiscountTier === 0} onChange={() => setSelectedDiscountTier(0)} className="h-4 w-4 border-gray-300 text-[#D4AF37] focus:ring-[#D4AF37]"/><label htmlFor="discount-all" className="ml-3 text-sm text-gray-600">All Products</label></div>
            {discountTiers.map(tier => (
                <div key={tier.value} className="flex items-center"><input id={`discount-${tier.value}`} type="radio" name="discount" checked={selectedDiscountTier === tier.value} onChange={() => setSelectedDiscountTier(tier.value)} className="h-4 w-4 border-gray-300 text-[#D4AF37] focus:ring-[#D4AF37]"/><label htmlFor={`discount-${tier.value}`} className="ml-3 text-sm text-gray-600">{tier.label}</label></div>
            ))}
          </div>
      </details>

      {occasionNames.length > 0 && (
        <details className="group py-2 border-b">
          <summary className="font-semibold cursor-pointer list-none flex justify-between items-center">
            Occasion <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span>
          </summary>
          <div className="space-y-2 mt-3">
            {occasionNames.map(o => (
              <FilterCheckbox key={o} id={`occ-${o}`} label={o} value={o} isChecked={selectedOccasions.has(o)} onChange={(val) => handleSetChange(setSelectedOccasions, val)} />
            ))}
          </div>
        </details>
      )}
      {allMetals.length > 0 && (<details className="group py-2 border-b"><summary className="font-semibold cursor-pointer list-none flex justify-between items-center">Material <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span></summary><div className="space-y-2 mt-3">{allMetals.map(m => (<FilterCheckbox key={m} id={`metal-${m}`} label={m} value={m} isChecked={selectedMetals.has(m)} onChange={(val) => handleSetChange(setSelectedMetals, val)} />))}</div></details>)}
      {allGemstones.length > 0 && (<details className="group py-2 border-b"><summary className="font-semibold cursor-pointer list-none flex justify-between items-center">Crystal Name <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span></summary><div className="space-y-2 mt-3">{allGemstones.map(g => (<FilterCheckbox key={g} id={`gem-${g}`} label={g} value={g} isChecked={selectedGemstones.has(g)} onChange={(val) => handleSetChange(setSelectedGemstones, val)} />))}</div></details>)}
      {allColors.length > 0 && (<details className="group py-2 border-b"><summary className="font-semibold cursor-pointer list-none flex justify-between items-center">Color <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span></summary><div className="space-y-2 mt-3">{allColors.map(c => (<FilterCheckbox key={c} id={`color-${c}`} label={c} value={c} isChecked={selectedColors.has(c)} onChange={(val) => handleSetChange(setSelectedColors, val)} />))}</div></details>)}
      {allSizes.length > 0 && (<details className="group py-2 border-b"><summary className="font-semibold cursor-pointer list-none flex justify-between items-center">Sizes <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span></summary><div className="space-y-2 mt-3">{allSizes.map(s => (<FilterCheckbox key={s} id={`size-${s}`} label={s} value={s} isChecked={selectedSizes.has(s)} onChange={(val) => handleSetChange(setSelectedSizes, val)} />))}</div></details>)}

      <details className="group py-2 border-b">
        <summary className="font-semibold cursor-pointer list-none flex justify-between items-center">Availability <span className="text-gray-400 text-xs transition-transform duration-200 group-open:rotate-90">&gt;</span></summary>
        <div className="flex items-center mt-3"><input id="in-stock" type="checkbox" checked={showInStockOnly} onChange={() => setShowInStockOnly(prev => !prev)} className="h-4 w-4 rounded border-gray-300 text-[#D4AF37] focus:ring-[#D4AF37]"/><label htmlFor="in-stock" className="ml-3 text-sm text-gray-600">In Stock Only</label></div>
      </details>
    </div>
  );

  return (
    <main className="bg-white">
      <div className="bg-[#FDFBF6] border-b border-gray-200"><div className="container mx-auto px-6 py-8 text-center"><h1 className="text-4xl font-bold text-gray-800">All Jewellery</h1><p className="text-gray-600 mt-2">Explore our entire collection of exquisite, handcrafted pieces.</p></div></div>
      
      <div className="container mx-auto px-6 py-8">
        <div className="flex">
          {/* Desktop Filters */}
          <aside className="hidden lg:block w-1/4 pr-8"><div className="sticky top-24"><FilterPanel /></div></aside>

          {/* Product Grid & Mobile Controls */}
          <div className="w-full lg:w-3/4">
            <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
              <div className="relative w-full md:max-w-sm">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input type="search" placeholder="Search for jewellery..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full p-2 pl-10 border border-gray-300 rounded-full focus:ring-2 focus:ring-[#D4AF37]" />
              </div>
              <div className="flex items-center justify-between w-full md:w-auto gap-4">
                <p className="text-sm text-gray-600 whitespace-nowrap">Showing <span className="font-bold">{isLoading ? '...' : filteredAndSortedProducts.length}</span> products</p>
                <select id="sort" value={sortOption} onChange={e => setSortOption(e.target.value)} className="p-2 border border-gray-300 rounded-md focus:ring-[#D4AF37] focus:border-[#D4AF37] text-sm">
                  <option value="all">Sort by</option><option value="featured">Featured</option><option value="new-arrivals">New Arrivals</option><option value="best-sellers">Best Sellers</option><option value="festive-sale">On Sale</option><option value="price-asc">Price: Low to High</option><option value="price-desc">Price: High to Low</option><option value="name-asc">Alphabetical: A-Z</option><option value="name-desc">Alphabetical: Z-A</option>
                </select>
                <button onClick={() => setIsFiltersOpen(true)} className="lg:hidden p-2 border rounded-md"><FilterIcon className="w-6 h-6" /></button>
              </div>
            </div>
            
            {isLoading ? (
               <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {Array.from({ length: 9 }).map((_, index) => (
                    <ProductCardSkeleton key={index} />
                ))}
              </div>
            ) : filteredAndSortedProducts.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {filteredAndSortedProducts.map((product, idx) => (
                  <ProductCard key={`${product.id}-${idx}`} product={product} isWishlisted={props.wishlistItems.some(item => item.productId === product.id)} isInCart={props.cartItems.some(item => item.productId === product.id)} {...props} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20"><h3 className="text-2xl font-semibold text-gray-700">No Products Found</h3><p className="text-gray-500 mt-2">Try adjusting your search or filters to find what you're looking for.</p></div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Filter Modal */}
      <div className={`fixed inset-0 z-50 lg:hidden transition-all duration-300 ${isFiltersOpen ? '' : 'pointer-events-none'}`}>
          <div className={`absolute inset-0 bg-black/50 transition-opacity ${isFiltersOpen ? 'opacity-100' : 'opacity-0'}`} onClick={() => setIsFiltersOpen(false)}></div>
          <div className={`relative w-full max-w-sm h-full bg-white shadow-xl transform transition-transform ease-in-out duration-300 ${isFiltersOpen ? 'translate-x-0' : '-translate-x-full'} flex flex-col`}>
            <div className="flex justify-between items-center p-4 border-b"><h2 className="text-xl font-semibold">Filters</h2><button onClick={() => setIsFiltersOpen(false)}><CloseIcon className="w-6 h-6" /></button></div>
            <div className="flex-1 overflow-y-auto p-4"><FilterPanel /></div>
            <div className="p-4 border-t bg-white"><button onClick={() => setIsFiltersOpen(false)} className="w-full bg-black text-white py-3 rounded-md font-bold">Apply Filters ({filteredAndSortedProducts.length} Results)</button></div>
          </div>
      </div>
    </main>
  );
};

export default AllProductsPage;
