/**
 * @file Centralized API service for interacting with a Django backend.
 * This service abstracts all data fetching, error handling, and data transformation
 * for various parts of the application.
 *
 * --- DJANGO INTEGRATION GUIDE ---
 * This file is the primary layer for connecting your React frontend to a Django REST Framework backend.
 * Currently, it uses mock data and simulates network delays. To connect to your real API:
 *
 * 1.  **Replace `mockFetch` with real `fetch` calls.** Each function includes a
 *     commented-out example of what a real `fetch` call would look like.
 *
 * 2.  **Configure `API_BASE_URL`**. Set this to your Django API's root URL
 *     (e.g., 'http://localhost:8000/api'). It's best to use environment variables for this.
 *
 * 3.  **Handle Authentication (JWT)**. The `getAuthHeaders` function is set up to retrieve a JWT
 *     token from localStorage and add it to the `Authorization: Bearer <token>` header. This is
 *     standard practice for token-based authentication with DRF Simple JWT.
 *
 * 4.  **Handle CSRF Tokens**. Django's session-based auth and form submissions require CSRF tokens.
 *     If you use DRF's `SessionAuthentication`, you'll need this. The `getCookie` function and
 *     the `X-CSRFToken` header in the state-changing requests (POST, PUT, DELETE) are included
 *     as best practice.
 *
 * 5.  **Error Handling**. The `fetch` examples include basic error handling (`if (!res.ok) throw...`). You should
 *     expand this to handle different HTTP status codes (e.g., 401 for unauthorized,
 *     403 for forbidden, 404 for not found) as needed for a robust user experience.
 *
 * 6. **Image Uploads**: For features like product image uploads, consider switching from
 *    base64 (as used in the mock data) to `multipart/form-data` for better performance. This would involve creating
 *    a `FormData` object in the API call and updating your Django view/serializer to handle file uploads.
 */

// Fix: Add Notification and NotificationType to imports
// Fix: Import ProductStatus to correctly type product statuses.
// import { Order, Product, Customer, Discount, Banner, UserProfile, Note, MainCategory, Material, SubCategory, Color, Occasion, RPD, VisitorRegionData, OrderStatus, Notification, NotificationType, CustomerStatus, ProductStatus } from '../types';
// Fix: Removed import from deprecated mockData.ts file and added mock data directly to this file.

// --- DJANGO INTEGRATION: Configuration ---
// Replace with your Django API's base URL. Use environment variables in a real app.
/**
 * @file apiService.ts
 * Connects React Frontend with Django REST Framework backend using Axios.
 */

import axios from "axios";
import {
  Order,
  Product,
  Customer,
  Discount,
  Banner,
  UserProfile,
  Note,
  MainCategory,
  Material,
  SubCategory,
  Color,
  Occasion,
  RPD,
  VisitorRegionData,
  OrderStatus,
  Notification,
} from "../types";
// Base URL of your Django API
// const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000/api";
const API_BASE_URL = 'http://127.0.0.1:8000/api'; // Example: 'http://127.0.0.1:8000/api'



// --- DJANGO INTEGRATION: CSRF Token Helper ---
/**
 * Retrieves a cookie value by name. Necessary for Django's CSRF protection with SessionAuthentication.
 * @param name The name of the cookie (usually 'csrftoken').
 * @returns The value of the cookie, or null if not found.
 */
function getCookie(name: string): string | null {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// --- DJANGO INTEGRATION: Authentication Headers Helper ---
/**
 * Constructs authentication headers for protected API endpoints using JWT.
 * @returns A HeadersInit object with the Authorization token if it exists.
 */
// const getAuthHeaders = (): HeadersInit => {
//     const token = localStorage.getItem('accessToken'); // Assuming you store the JWT access token here
//     const headers: HeadersInit = {
//         'Content-Type': 'application/json',
//     };
//     if (token) {
//         headers['Authorization'] = `Bearer ${token}`;
//     }
//     return headers;
// };


// ====================
// AUTH HEADERS HELPERS
// ====================

const getAuthHeaders = () => {
  const token = localStorage.getItem("accessToken");
  return token
    ? { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }
    : { "Content-Type": "application/json" };
};


/**
 * A mock fetch utility to simulate API calls with a delay.
 * In a real application, this entire function is replaced by actual `fetch` calls.
 */

// ====================
// GENERIC API WRAPPER
// ====================

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: getAuthHeaders(),
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("accessToken");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 Unauthorized globally
api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response && error.response.status === 401) {
      console.warn("Unauthorized — redirecting to login");
      localStorage.removeItem("accessToken");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);




// =================================
// ORDERS API
// =================================

export const getOrders = async (): Promise<Order[]> => {
  const res = await api.get("/orders/");
  return res.data;
};

export const createOrder = async (orderData: Partial<Order>): Promise<Order> => {
  const res = await api.post("/orders/", orderData);
  return res.data;
};

export const updateOrderStatus = async (orderId: number, status: OrderStatus) => {
  const res = await api.patch(`/orders/${orderId}/`, { status });
  return res.data;
};


// =================================
// PRODUCTS API
// =================================

export const getProducts = async (): Promise<Product[]> => {
  const res = await api.get("/products/");
  return res.data;
};

export const createProduct = async (productData: Partial<Product>): Promise<Product> => {
  const res = await api.post("/products/", productData);
  return res.data;
};

export const updateProduct = async (productData: Product): Promise<Product> => {
  const res = await api.put(`/products/${productData.id}/`, productData);
  return res.data;
};

export const deleteProduct = async (id: number): Promise<void> => {
  await api.delete(`/products/${id}/`);
};

// =================================
// CUSTOMERS API
// =================================

export const getCustomers = async (): Promise<Customer[]> => {
  const res = await api.get("/customers/");
  return res.data;
};
//ddddd
export const updateCustomerStatus = async (customerId: number, status: Customer['status']): Promise<{ success: true }> => {
    MOCK_CUSTOMERS = MOCK_CUSTOMERS.map(c => c.id === customerId ? { ...c, status } : c);
    return mockFetch({ success: true });
};
export const deleteCustomer = async (customerId: number): Promise<{ success: true }> => {
    MOCK_CUSTOMERS = MOCK_CUSTOMERS.filter(c => c.id !== customerId);
    return mockFetch({ success: true });
};

// =================================
// DISCOUNTS API
// =================================

export const getDiscounts = (): Promise<Discount[]> => mockFetch(MOCK_DISCOUNTS);
export const createDiscount = async (discountData: Omit<Discount, 'id'>): Promise<Discount> => {
    const newDiscount: Discount = { id: Date.now(), ...discountData };
    MOCK_DISCOUNTS = [newDiscount, ...MOCK_DISCOUNTS];
    return mockFetch(newDiscount);
};
export const updateDiscount = async (discountData: Discount): Promise<Discount> => {
    MOCK_DISCOUNTS = MOCK_DISCOUNTS.map(d => d.id === discountData.id ? discountData : d);
    return mockFetch(discountData);
};
export const deleteDiscount = async (discountId: number): Promise<{ success: true }> => {
    MOCK_DISCOUNTS = MOCK_DISCOUNTS.filter(d => d.id !== discountId);
    return mockFetch({ success: true });
};


// =================================
// BANNERS API
// =================================

export const getBanners = (): Promise<Banner[]> => mockFetch(MOCK_BANNERS);
export const createBanner = async (bannerData: Omit<Banner, 'id'>): Promise<Banner> => {
    const newBanner: Banner = { id: Date.now(), ...bannerData };
    MOCK_BANNERS = [newBanner, ...MOCK_BANNERS];
    return mockFetch(newBanner);
};
export const updateBanner = async (bannerData: Banner): Promise<Banner> => {
    MOCK_BANNERS = MOCK_BANNERS.map(b => b.id === bannerData.id ? bannerData : b);
    return mockFetch(bannerData);
};
export const deleteBanner = async (bannerId: number): Promise<{ success: true }> => {
    MOCK_BANNERS = MOCK_BANNERS.filter(b => b.id !== bannerId);
    return mockFetch({ success: true });
};


// =================================
// USER PROFILE & NOTIFICATIONS API
// =================================

// export const getUserProfile = (): Promise<UserProfile> => mockFetch(MOCK_USER_PROFILE);
export const getUserProfile = async (): Promise<UserProfile> => {
  const res = await api.get("/users/profile/");
  return res.data;
};

export const updateUserProfile = async (profile: UserProfile): Promise<UserProfile> => {
  const res = await api.put("/users/profile/", profile);
  return res.data;
};

// Fix: Add missing getNotifications function
export const getNotifications = async (): Promise<Notification[]> => {
  const res = await api.get("/notifications/");
  return res.data;
};

// Fix: Add missing sendEmailNotification function
export const sendEmailNotification = async (emailData: { to: string; subject: string; body: string; }): Promise<{ success: true }> => {
    console.log('--- MOCK EMAIL ---');
    console.log(`To: ${emailData.to}`);
    console.log(`Subject: ${emailData.subject}`);
    console.log('Body:');
    console.log(emailData.body);
    console.log('--- END MOCK EMAIL ---');
    return mockFetch({ success: true }, 100);
};

// =================================
// NOTES API
// =================================
// export const getNotes = (): Promise<Note[]> => mockFetch(MOCK_NOTES);
export const getNotes = async (): Promise<Note[]> => {
  const res = await api.get("/notes/");
  return res.data;
};
export const createNote = async (content: string): Promise<Note> => {
  const res = await api.post("/notes/", { content });
  return res.data;
};

// Update a note
export const updateNote = async (noteId: number, content: string): Promise<Note> => {
  const res = await api.put(`/notes/${noteId}/`, { content });
  return res.data;
};

// Delete a note
export const deleteNote = async (noteId: number): Promise<{ success: true }> => {
  await api.delete(`/notes/${noteId}/`);
  return { success: true };
};

// =================================
// PRODUCT ATTRIBUTES API
// =================================

// export const getMainCategories = (): Promise<MainCategory[]> => mockFetch(MOCK_MAIN_CATEGORIES);
export const getMainCategories = async (): Promise<MainCategory[]> => {
  const res = await api.get("/main-categories/");
  return res.data;
};

export const createMainCategory = async (name: string) => {
  const res = await api.post("/main-categories/", { name });
  return res.data;
};

export const deleteMainCategory = async (id: number) => {
  await api.delete(`/main-categories/${id}/`);
};

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("accessToken");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ------------------ MATERIALS ------------------

export const getMaterials = async (): Promise<Material[]> => {
  const res = await api.get("/materials/");
  return res.data;
};

export const createMaterial = async (name: string): Promise<Material> => {
  const res = await api.post("/materials/", { name });
  return res.data;
};

export const deleteMaterial = async (id: number): Promise<{ success: boolean }> => {
  await api.delete(`/materials/${id}/`);
  return { success: true };
};

// ------------------ SUBCATEGORIES ------------------

export const getSubCategories = async (): Promise<SubCategory[]> => {
  const res = await api.get("/subcategories/");
  return res.data;
};

export const createSubCategory = async (name: string): Promise<SubCategory> => {
  const res = await api.post("/subcategories/", { name });
  return res.data;
};

export const deleteSubCategory = async (id: number): Promise<{ success: boolean }> => {
  await api.delete(`/subcategories/${id}/`);
  return { success: true };
};

// ------------------ COLORS ------------------

export const getColors = async (): Promise<Color[]> => {
  const res = await api.get("/colors/");
  return res.data;
};

export const createColor = async (name: string): Promise<Color> => {
  const res = await api.post("/colors/", { name });
  return res.data;
};

export const deleteColor = async (id: number): Promise<{ success: boolean }> => {
  await api.delete(`/colors/${id}/`);
  return { success: true };
};

// ------------------ OCCASIONS ------------------

export const getOccasions = async (): Promise<Occasion[]> => {
  const res = await api.get("/occasions/");
  return res.data;
};

export const createOccasion = async (name: string): Promise<Occasion> => {
  const res = await api.post("/occasions/", { name });
  return res.data;
};

export const deleteOccasion = async (id: number): Promise<{ success: boolean }> => {
  await api.delete(`/occasions/${id}/`);
  return { success: true };
};

// =================================
// RICH PRODUCT DESCRIPTION (RPD) API
// =================================

// const api = axios.create({
//   baseURL: API_BASE_URL,
//   headers: {
//     "Content-Type": "application/json",
//     Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
//   },
// });



// export const getRPDs = (): Promise<RPD[]> => mockFetch(MOCK_RPD_DATA);
export const getRPDs = async (): Promise<RPD[]> => {
  const res = await api.get("/rpd/");
  return res.data;
};

export const createRPD = async (rpdData: Omit<RPD, "id">): Promise<RPD> => {
  const res = await api.post("/rpd/", rpdData);
  return res.data;
};

export const updateRPD = async (rpdData: RPD): Promise<RPD> => {
  const res = await api.put(`/rpd/${rpdData.id}/`, rpdData);
  return res.data;
};

export const deleteRPD = async (rpdId: number): Promise<{ success: true }> => {
  await api.delete(`/rpd/${rpdId}/`);
  return { success: true };
};

// =================================
// ANALYTICS API
// =================================

export const getVisitorData = async (): Promise<VisitorRegionData[]> => {
  const res = await api.get("/analytics/");
  return res.data;
};